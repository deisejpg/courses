#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jul 18 09:03:23 2018

@author: walling
"""
# Linear Regression
from keras.models import Sequential
from keras.layers import Dense
from keras.datasets import boston_housing

# Load and Split Data
(x_train, y_train), (x_test, y_test) = boston_housing.load_data()

# Build Model
model = Sequential()

model.add(Dense(8, init='normal', input_dim=13, activation='sigmoid'))  # Input + Hidden 1
model.add(Dense(8, init='normal', activation='sigmoid')) #  Hidden 2
model.add(Dense(1, init='normal')) # Output, default activation = linear

model.compile(loss='mean_squared_error',
              optimizer='sgd',
              metrics=['mse', 'mape', 'mae'])

# Train
model.fit(x_train, y_train, epochs=10, batch_size=32)

# Evaluate
model.evaluate(x_test, y_test, batch_size=32)
